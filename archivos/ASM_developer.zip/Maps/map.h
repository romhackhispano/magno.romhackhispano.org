/*
   map.h
   Include file for mapping dll
*/
#ifndef __map_h
#define __map_h

#if defined(__cplusplus)
extern "C" {
#endif

#if defined(__DJGPP__)
#define STDCALL __attribute__((stdcall))
#define EXPORTNAME(name) asm(name);
#else
#define STDCALL __stdcall
#define EXPORTNAME(name)
#endif

int STDCALL DllId() EXPORTNAME("DllId");
unsigned long STDCALL pc2snes(unsigned long pcaddr) EXPORTNAME("pc2snes");
unsigned long STDCALL snes2pc(unsigned long snaddr) EXPORTNAME("snes2pc");

#if defined(__cplusplus)
}
#endif

#endif