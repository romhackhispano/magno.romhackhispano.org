Installing mapping DLL's
------------------------

1) Either stick em in the same directory as asmdev.exe
2) Or stick em in the WINDOWS DIRECTORY
3) Stick them somewhere and it the path in the PATH variable in your
autoexec.