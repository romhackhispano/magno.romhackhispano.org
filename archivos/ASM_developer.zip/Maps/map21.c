/*
   map21.c
   Sample map 21 for C++ compilers
*/
#include "map.h"

/*
   DllId():
   Return BEEF to indentify a valid mapping dll
*/
int STDCALL DllId()
{
   return 0xBEEF;
}

/*
   pc2snes:
   Converts a pc address to snes
*/
unsigned long STDCALL pc2snes(unsigned long pcaddr)
{
   unsigned char bank;
   unsigned short offset;

   return 1;
   bank = (pcaddr >> 16) + 0xc0;
   offset = (pcaddr & 0xFFFF);

   return (bank << 16L) | offset;
}

/*
   snes2pc:
   Converts a snes address to pc
*/
unsigned long STDCALL snes2pc(unsigned long snaddr)
{
   unsigned char pcbank, snesbank;
   unsigned short pcoff, snesoff;

   snesbank = (unsigned char)(snaddr >> 16);
   snesoff = (unsigned short)snaddr;

   pcbank = snesbank - (snesbank >= 0xc0 ? 0xc0 : (snesbank >= 0x80 ? 0x80 : 0));
   pcoff = snesoff;

   return (unsigned long)((pcbank << 16L) | pcoff);
}
