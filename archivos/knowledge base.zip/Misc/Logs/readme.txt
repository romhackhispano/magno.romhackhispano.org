Well, while you're waiting for some meaningful, structured docs on the SNES 
here's some (questions and) answers I've been getting from various people 
who know their way around the SNES.  There's some chat logs, and some e-mail 
Q&A.  Notice the dates on these files--the files with earlier dates have more
"stupid" questions in them. :)

	-Qwertie

JG=Jason G. DT=DuncanThrax PR=Paul Robson
Q=Questions A=Answers