SNES HDMA, Window Mask, and Fixed Color Subtraction demo
(C) 2001 Realtime Simulations and Roleplaying Games

=========================================================
		Ye Old Disclaimer
=========================================================
The authors of this program make no guarantees of its
fitness for any particular purpose, nor are they 
responsible for any damage caused by the use or misuse of
their work.  Use at your own risk, and please don't sue
us because we're poor.


=========================================================
		Ye Old Introduction
=========================================================
The HDMADEMO.ASM program demonstrates using fixed color
subtraction to darken a rectangular region of BG1.  A
window mask is used to limit the left and right sides of
the box, and HDMA is used to enable and disable the box
at the appropriate top and bottom positions.

The SetupColorWindow subroutine sets up the fixed color
subtraction and window mask for the color window.

The SetupHDMA subroutine sets up two HDMA transfers, one
to set the Left side of Window 1 and the other to set
the Right side of Window 1.
